const mysql = require('mysql');

const connConfig = {
    host: "lconf.inf.ufes.br",
    port: 3306,
    user: "devwebII",
    password: "Faesa123!",
    database: "alex_louzada"
}

// const connConfig_aux = {
//     host: "localhost",
//     port: 8889,
//     user: "root",
//     password: "root",
//     database: "otavio_lube"
// }

exports.openConnection = () => {
    let connection = mysql.createConnection(connConfig);
    connection.connect(err => {
        if (err) return console.log(err);
        console.log('Conexão estabelecida com sucesso!');
    });
    return connection;
}

exports.closeConnection = connection => {
    connection.end(err => {
        if (err) return console.log(err);
        console.log("Conexão encerrada com sucesso!");
    });
}

exports.createDBStructure = () => {
    let connection = this.openConnection();

    let sql = "SHOW TABLES LIKE 'Users';";

    connection.query(sql, (err, results, fields) => {
        if (err) return console.log(err);
        if (Array.from(results).length > 0) {
            users_table_flag = true;
            console.log('A tabela Users já existe!')
        } else {
            sql = "CREATE TABLE IF NOT EXISTS Users (id INT NOT NULL AUTO_INCREMENT, firstname VARCHAR(50) NOT NULL, lastname VARCHAR(50) NOT NULL, password VARCHAR(256) NOT NULL, cpf CHAR(11), email VARCHAR(100),picture VARCHAR(256), PRIMARY KEY (id));";

            connection.query(sql, (err, results, fields) => {
                if (err) return console.log(err);
                console.log("Tabela Users criada com sucesso!");
            });
        }
    });

    sql = "SHOW TABLES LIKE 'Transactions';";

    connection.query(sql, (err, results, fields) => {
        if (err) return console.log(err);
        if (Array.from(results).length > 0) {
            console.log('A tabela Transactions já existe!')
        } else {
            sql = "CREATE TABLE IF NOT EXISTS Transactions (id INT NOT NULL AUTO_INCREMENT, transaction_date DATETIME NOT NULL, ativo CHAR(5) NOT NULL, quantidade INT NOT NULL, preco DECIMAL(15,2) NOT NULL, descricao VARCHAR(300), userId INT, PRIMARY KEY (id), FOREIGN KEY (userId) REFERENCES Users(id));";

            connection.query(sql, (err, results, fields) => {
                if (err) return console.log(err);
                console.log("Tabela Transactions criada com sucesso!");
            });
        }
    });

    sql = "SHOW TABLES LIKE 'Stocks';";

    connection.query(sql, (err, results, fields) => {
        if (err) return console.log(err);
        if (Array.from(results).length > 0) {
            stocks_table_flag = true;
            console.log('A tabela Stocks já existe!')
        } else {
            sql = "CREATE TABLE IF NOT EXISTS Stocks (id INT NOT NULL AUTO_INCREMENT, code CHAR(5) NOT NULL, descricao VARCHAR(300), userId INT, PRIMARY KEY (id), FOREIGN KEY (userId) REFERENCES Users(id));";

            connection.query(sql, (err, results, fields) => {
                if (err) return console.log(err);
                console.log("Tabela Stocks criada com sucesso!");
            });
        }
    });
    
    //this.closeConnection(connection);
}