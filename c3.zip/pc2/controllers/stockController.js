const stockModel = require('../models/stocksModel');

class stockController{
    constructor(){}

    async listarAtivos(user){
        try{
            const resultado = await stockModel.listStocks(user);
            return resultado;
        }catch(error){
            console.error('Erro ao pegar ativos', error);
        }
    }
    
    async criarAtivo(stock, user){
        try{
            const resultado = await stockModel.insertStock(stock, user);
            if(resultado.affectedRows > 0){
                console.log("Ativo inserido com sucesso!");
                return {
                    value: true,
                    message: "Ativo inserido com sucesso!"
                }
            }else{
                console.log("Erro ao inserir ativo");
                return {
                    value: false,
                    message: "Erro ao inserir ativo!"
                }
            }
        }catch(erro){
            
        }
    }
}

module.exports = new stockController();