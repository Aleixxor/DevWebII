const db = require('../infra/db');

exports.insertUser = user => {
    let connection = db.openConnection();
    let sql = `INSERT INTO Users (firstname, lastname, email, password) VALUES ('${user.firstname}', '${user.lastname}', '${user.email}', '${user.password}');`

    return new Promise((resolve, reject) => {
        connection.query(sql, (err, results, fields) => {
            if(err){
                console.log(err);
                reject(err);
            }
            console.log(`User ${user.firstname} inserido com sucesso!`);
            // console.log("Resultado:", results);
            resolve(results);
        });
        db.closeConnection(connection);
    });
}

exports.listUsers = () => {
    let connection = db.openConnection();
    let sql = `SELECT * FROM Users;`

    return new Promise((resolve, reject) => {
        connection.query(sql, (err, results, fields) => {
            if(err) reject(err);
            console.log(`Users listados com sucesso!`);
            resolve(results);
        });
    });
}

exports.deleteUser = userId => {
    let connection = db.openConnection();
    let sql = `DELETE FROM Users WHERE Users.id = ${userId};`

    return new Promise((resolve, reject) => {
        connection.query(sql, (err, results, fields) => {
            if(err) reject(err);
            console.log(`User deletado inserido com sucesso!`);
            resolve(results);
        });
    });
}

exports.userExists = user => {
    let connection = db.openConnection();
    let sql = `SELECT * FROM Users WHERE email = '${user.email}' AND password = '${user.password}';`;

    return new Promise((resolve, reject) => {
        connection.query(sql, (err, results, fields) => {
            if(err) reject(err);
            resolve(results);
        });
    });
}

exports.emailExists = email => {
    let connection = db.openConnection();
    let sql = `SELECT * FROM Users WHERE email = '${email}'`;

    return new Promise((resolve, reject) => {
        connection.query(sql, (err, results, fields) => {
            if(err) reject(err);
            resolve(results);
        })
    })
}
