const db = require('../infra/db');

exports.insertStock = (stock, user) => {
    let connection = db.openConnection();
    let sql = `INSERT INTO Stocks (code, descricao, userId) VALUES ('${stock.code}', '${stock.descricao}', '${user.id}');`

    return new Promise((resolve, reject) => {
        connection.query(sql, (err, results, fields) => {
            if(err){
                console.log(err);
                reject(err);
            }
            console.log(`Ação ${stock.code} inserida com sucesso!`);
            // console.log("Resultado:", results);
            resolve(results);
        });
        db.closeConnection(connection);
    });
}

exports.listStocks = (user) => {
    let connection = db.openConnection();
    let sql = `SELECT * FROM Stocks WHERE userId = ${user.id};`

    return new Promise((resolve, reject) => {
        connection.query(sql, (err, results, fields) => {
            if(err) reject(err);
            console.log(`Ações listadas com sucesso!`);
            resolve(results);
        });
    });
}

exports.deleteStock = stockId => {
    let connection = db.openConnection();
    let sql = `DELETE FROM Stocks WHERE Stocks.id = ${stockId};`

    return new Promise((resolve, reject) => {
        connection.query(sql, (err, results, fields) => {
            if(err) reject(err);
            console.log(`Ação deletada com sucesso!`);
            resolve(results);
        });
    });
}

exports.stockExists = stock => {
    let connection = db.openConnection();
    let sql = `SELECT * FROM Stocks WHERE id = '${stock.id}' AND code = '${stock.code}';`;

    return new Promise((resolve, reject) => {
        connection.query(sql, (err, results, fields) => {
            if(err) reject(err);
            resolve(results);
        });
    });
}

exports.codeExists = code => {
    let connection = db.openConnection();
    let sql = `SELECT * FROM Stocks WHERE code = '${code}'`;

    return new Promise((resolve, reject) => {
        connection.query(sql, (err, results, fields) => {
            if(err) reject(err);
            resolve(results);
        })
    })
}
