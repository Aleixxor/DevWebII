var express = require('express');
var router = express.Router();

router.get('/', (req, res) => {
  if(req.session.user){
    res.render('dashboard', { layout: 'logged', nome: req.session.user.firstname });
  }else{
    res.render('login', {
      layout: false,
      habilitarAlert: true,
      classe: 'danger',
      message: "Você precisa estar logado para acessar este recurso!"
    })
  }
});

module.exports = router;
