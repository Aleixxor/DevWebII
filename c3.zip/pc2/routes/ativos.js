var express = require('express');
var router = express.Router();
var stockController = require('./../controllers/stockController')

router.get('/', (req, res) => {
  if(req.session.user){
    const listar = async () => {
      try {
        const resultado = await stockController.listarAtivos(req.session.user);
        console.log(resultado);
        res.render('ativos', {
          layout: 'logged',
          ativos: resultado
        });
      }
      catch (err) {
        console.log(err);
      }
    }
    listar();
  }else{
    res.render('login', {
      layout: false,
      habilitarAlert: true,
      classe: 'danger',
      message: "Você precisa estar logado para acessar este recurso!"
    })
  }
});

router.post('/', (req, res) => {
  if(req.session.user){
    console.log(req.body);
    console.log(req.session.user);
    const stock = {
      code: req.body.codigo,
      descricao: req.body.descricao
    }
    const inserir = async () => {
      try{
        const resultado = await stockController.criarAtivo(stock, req.session.user);
        res.render('ativos', {
          layout: 'logged'
        });
        console.log(resultado);
      }
      catch (err) {
        console.log(err);
      }
    }
    inserir();
  }else{
    res.render('login', {
      layout: false,
      habilitarAlert: true,
      classe: 'danger',
      message: "Você precisa estar logado para acessar este recurso!"
    })
  }
})

module.exports = router;
