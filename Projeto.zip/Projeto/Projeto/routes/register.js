var express = require('express');
var router = express.Router();

/* GET Register Page page. */
router.get('/', function(req, res, next) {
    res.render('register');
  //res.render('login', { title: 'Lucas' });
});

module.exports = router;
