var express = require('express');
var router = express.Router();

/* GET Tables Page. */
router.get('/', function(req, res, next) {
    res.render('tables');
  //res.render('login', { title: 'Lucas' });
});

module.exports = router;
