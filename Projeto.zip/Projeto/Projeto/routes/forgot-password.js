var express = require('express');
var router = express.Router();

/* GET Forgot-Password Page page. */
router.get('/', function (req, res, next) {
    res.render('forgot-password');
    //res.render('login', { title: 'Lucas' });
});

module.exports = router;
