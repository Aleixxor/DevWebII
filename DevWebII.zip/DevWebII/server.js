var express = require('express');
var faker = require('faker');
var bodyParser = require('body-parser');
var expressLayouts = require('express-ejs-layouts');
var app = express();
var port = 3000;

app.set('view engine', 'ejs');
app.use(expressLayouts);
app.use(bodyParser.urlencoded({ extended: false }));

// app.get('/about', (req, res) => {
//     var users = [{
//         name: faker.name.findName(),
//         email: faker.internet.email(),
//         avatar: 'http://placekitten.com/300/300'
//     }, {
//         name: faker.name.findName(),
//         email: faker.internet.email(),
//         avatar: 'http://placekitten.com/400/300'
//     }, {
//         name: faker.name.findName(),
//         email: faker.internet.email(),
//         avatar: 'http://placekitten.com/500/300'
//     }]

//     res.render('pages/about', {usuarios: users});
// });

app.get('/', (req, res) => {
    res.render('pages/index');
});

app.get('/404', (req, res) => {
    res.render('pages/404')
});

app.get('/blank', (req, res) => {
    res.render('pages/blank')
});

app.get('/charts', (req, res) => {
    res.render('pages/charts')
});

app.get('/forgot-password', (req, res) => {
    res.render('pages/forgot-password')
});

app.get('/login', (req, res) => {
    res.render('pages/login')
});

app.get('/register', (req, res) => {
    res.render('pages/register')
});

app.get('/tables', (req, res) => {
    res.render('pages/tables')
});

app.use(express.static(__dirname + '/public'));
app.use(express.static(__dirname + '/node_modules'));
app.listen(port, ()=>{
    console.log('Servidor iniciado com sucesso em http://localhost:' + port);
});